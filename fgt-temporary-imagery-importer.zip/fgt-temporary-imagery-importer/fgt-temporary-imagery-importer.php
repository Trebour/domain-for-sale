<?php
/**
 * Plugin Name: FGT Temporary Imagery Importer
 * Description: Temporary authenticated importer for the approved Future Green Technology imagery pack. Remove after the implementation pass.
 * Version: 1.0.0
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
add_action( 'rest_api_init', function () {
 register_rest_route( 'fgt-imagery/v1', '/ping', array('methods'=>WP_REST_Server::READABLE,'permission_callback'=>function(){return current_user_can('upload_files');},'callback'=>function(){return array('ok'=>true);}));
 register_rest_route( 'fgt-imagery/v1', '/import-bundle', array('methods'=>WP_REST_Server::CREATABLE,'permission_callback'=>function(){return current_user_can('upload_files');},'callback'=>'fgt_temporary_import_bundle'));
});
function fgt_temporary_find_attachment($key){$m=get_posts(array('post_type'=>'attachment','post_status'=>'inherit','posts_per_page'=>1,'fields'=>'ids','meta_key'=>'_fgt_asset_key','meta_value'=>$key));return empty($m)?0:(int)$m[0];}
function fgt_temporary_import_bundle(WP_REST_Request $r){
 if(!class_exists('ZipArchive')) return new WP_Error('zip_unavailable','ZipArchive is unavailable.',array('status'=>500));
 $data=(string)$r->get_param('data'); $manifest=$r->get_param('manifest'); if(is_string($manifest))$manifest=json_decode($manifest,true);
 if(!$data||!is_array($manifest))return new WP_Error('missing_payload','Bundle data and manifest are required.',array('status'=>400));
 $binary=base64_decode($data,true); if(false===$binary)return new WP_Error('invalid_base64','Invalid bundle.',array('status'=>400));
 if(strlen($binary)>12*MB_IN_BYTES)return new WP_Error('bundle_too_large','Bundle exceeds 12 MB.',array('status'=>413));
 $u=wp_upload_dir(); if(!empty($u['error']))return new WP_Error('upload_dir',$u['error'],array('status'=>500));
 $root=trailingslashit($u['basedir']).'fgt-imagery-import-'.wp_generate_uuid4(); wp_mkdir_p($root); $zp=$root.'/bundle.zip'; file_put_contents($zp,$binary); $ed=$root.'/files'; wp_mkdir_p($ed);
 $z=new ZipArchive(); if(true!==$z->open($zp)){fgt_temporary_remove_tree($root);return new WP_Error('zip_open','Could not open bundle.',array('status'=>400));} $z->extractTo($ed);$z->close();
 require_once ABSPATH.'wp-admin/includes/image.php'; $out=array();
 foreach($manifest as $i){
  $key=sanitize_key($i['asset_key']??'');$src=sanitize_file_name($i['source']??'');$fn=sanitize_file_name($i['filename']??$src);$title=sanitize_text_field($i['title']??pathinfo($fn,PATHINFO_FILENAME));$alt=sanitize_text_field($i['alt_text']??'');$cap=sanitize_textarea_field($i['caption']??'');$desc=wp_kses_post($i['description']??'');
  if(!$key||!$src||!$fn){$out[]=array('asset_key'=>$key,'error'=>'Invalid manifest item.');continue;}
  $id=fgt_temporary_find_attachment($key); if($id){$m=wp_get_attachment_metadata($id);$out[]=array('asset_key'=>$key,'id'=>$id,'url'=>wp_get_attachment_url($id),'width'=>$m['width']??null,'height'=>$m['height']??null,'existing'=>true);continue;}
  $sp=$ed.'/'.$src; if(!is_file($sp)){$out[]=array('asset_key'=>$key,'error'=>'Source missing.');continue;}
  $up=wp_upload_bits($fn,null,file_get_contents($sp)); if(!empty($up['error'])){$out[]=array('asset_key'=>$key,'error'=>$up['error']);continue;}
  $ft=wp_check_filetype($up['file'],null);$id=wp_insert_attachment(array('post_mime_type'=>$ft['type'],'post_title'=>$title,'post_content'=>$desc,'post_excerpt'=>$cap,'post_status'=>'inherit'),$up['file']);
  if(is_wp_error($id)){@unlink($up['file']);$out[]=array('asset_key'=>$key,'error'=>$id->get_error_message());continue;}
  $m=wp_generate_attachment_metadata($id,$up['file']);wp_update_attachment_metadata($id,$m);update_post_meta($id,'_fgt_asset_key',$key);if($alt!=='')update_post_meta($id,'_wp_attachment_image_alt',$alt);
  $out[]=array('asset_key'=>$key,'id'=>(int)$id,'url'=>wp_get_attachment_url($id),'width'=>$m['width']??null,'height'=>$m['height']??null,'bytes'=>filesize($up['file']),'existing'=>false);
 }
 fgt_temporary_remove_tree($root);return array('imported'=>$out);
}
function fgt_temporary_remove_tree($p){if(!is_dir($p))return;$it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($p,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::CHILD_FIRST);foreach($it as $x){$x->isDir()?@rmdir($x->getPathname()):@unlink($x->getPathname());}@rmdir($p);}
